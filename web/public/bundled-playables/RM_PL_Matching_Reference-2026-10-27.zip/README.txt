Royal Match matching-flow playable (EN), Luna playground wrapper.
Source: https://playground.lunalabs.io/preview/414475/746409/ccb49094d9f6f247f0a2b158f4de579c87284b474f570fab22d07874c72a0504
